import React, { Component } from "react";

export default class Contact extends Component {
  render() {
    const contactUsInfo = {
      //   border: "1px solid black",
      //   position: "relative",
      boxShadow: "0px 10px 10px #888888",
    };
    const imgPic = {
      height: "300px",
      width: "300px",
      border: "1px solid black",
      borderRadius: "50%",
      marginTop: "20px",
      marginBottom: "20px",
    };
    return (
      <div>
        <div class="contact-us-main mt-5">
          <h3 class="text-center">Contact Us</h3>
          <div class="container">
            <input
              type="text"
              class="form-control mx-auto"
              placeholder="Location"
              style={{ width: "50%" }}
            />

            <div
              class="contact-us-info mt-3 mx-auto text-center"
              style={({ width: "70%" }, contactUsInfo)}
            >
              <img
                src="https://images.unsplash.com/photo-1611594177124-2d49ee1a886f?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=1500&q=80"
                alt=""
                style={imgPic}
              />
              <hr />
              <div class="info">
                <p>
                  <b>Name:</b>Pravin Kumar
                </p>
                <p>
                  <b>Contact No:</b>9404849487
                </p>
                <p>
                  <b>Address:</b>Btm
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
