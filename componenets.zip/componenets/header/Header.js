import React, { Component } from "react";
import { Link } from "react-router-dom";

export default class Header extends Component {
  logout = () => {
    this.props.update(false);
  };

  render() {
    let userAuth, regLink, contactLink, serviceLink;
    if (this.props.isLoging) {
      userAuth = (
        <button className="btn btn-primary" onClick={this.logout}>
          Logout
        </button>
      );
      contactLink = <button className="btn btn-primary">AddSkill</button>;
      serviceLink = <button className="btn btn-primary">Project</button>;
    } else {
      contactLink = <NavLinkComp link="/contact" title="Contact" />;
      serviceLink = <NavLinkComp link="/services" title="Services" />;
      userAuth = <NavLinkComp link="/login" title="Login" />;
      regLink = <NavLinkComp link="/register" title="Register" />;
    }
    return (
      <div>
        <nav className="navbar navbar-expand-lg navbar-dark bg-primary">
          <Link className="navbar-brand" to="/">
            EMPLOYEE
          </Link>
          <ul className="navbar-nav">
            <ul className="navbar-nav ml-auto">
              <li className="nav-item active">{contactLink}</li>
              <li className="nav-item">{serviceLink}</li>
            </ul>
          </ul>

          <button
            className="navbar-toggler"
            type="button"
            data-toggle="collapse"
            data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav ml-auto">
              <li className="nav-item active">{userAuth}</li>
              <li className="nav-item">{regLink}</li>
            </ul>
          </div>
        </nav>
      </div>
    );
  }
}

function NavLinkComp({ link, title }) {
  return (
    <div>
      <Link className="nav-link active" to={link}>
        {title}
      </Link>
    </div>
  );
}
