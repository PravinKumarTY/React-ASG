import React, { Component } from "react";

export default class Home extends Component {
  render() {
    return (
      <div>
        <div className="home_main mt-5" id="homeDiv">
          <h3 className="text-center">Home</h3>
          <div className="container">
            <input
              type="text"
              className="form-control"
              placeholder="Location"
            />
            <div className="row mt-3">
              <div className="col-lg-4 col-md-4 col-10 my-2">
                <img
                  src="https://images.unsplash.com/photo-1419133126304-d17b34c34d76?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=750&q=80"
                  alt=""
                  style={{ height: "300px", width: "350px" }}
                />
                <h6>Kayaking Trip ⭐⭐⭐⭐</h6>
              </div>
              <div className="col-lg-4 col-md-4 col-10 my-2">
                <img
                  src="https://images.unsplash.com/photo-1469286663112-f58a16c6f075?ixlib=rb-1.2.1&ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&auto=format&fit=crop&w=401&q=80"
                  alt=""
                  style={{ height: "300px", width: "350px" }}
                />
                <h6>Colvis Trip ⭐⭐⭐</h6>
              </div>
              <div className="col-lg-4 col-md-4 col-10 my-2">
                <img
                  src="https://images.unsplash.com/photo-1471306224500-6d0d218be372?ixlib=rb-1.2.1&ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&auto=format&fit=crop&w=1534&q=80"
                  alt=""
                  style={{ height: "300px", width: "350px" }}
                />
                <h6>San Francisco ⭐⭐⭐⭐⭐</h6>
              </div>
            </div>

            <div className="row">
              <div className="col-lg-4 col-md-4 col-10 my-2">
                <img
                  src="https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=708&q=80"
                  alt=""
                  style={{ height: "300px", width: "350px" }}
                />
                <h6>Arches National Park ⭐⭐</h6>
              </div>
              <div className="col-lg-4 col-md-4 col-10 my-2">
                <img
                  src="https://images.unsplash.com/photo-1515868406999-b29e577822ec?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=750&q=80"
                  alt=""
                  style={{ height: "300px", width: "350px" }}
                />
                <h6>Chicago ⭐⭐⭐</h6>
              </div>
              <div className="col-lg-4 col-md-4 col-10 my-2">
                <img
                  src="https://images.unsplash.com/photo-1546790132-c896036f266a?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=750&q=80"
                  alt=""
                  style={{ height: "300px", width: "350px" }}
                />
                <h6>New York ⭐⭐⭐⭐⭐</h6>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
