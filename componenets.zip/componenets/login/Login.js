import { useState } from "react";
import { useHistory } from "react-router-dom";

function Login({ update }) {
  const history = useHistory();
  const [data, setData] = useState({
    email: "",
    password: "",
  });
  const [allUsers] = useState(JSON.parse(localStorage.getItem("allUsers")));

  const handleOnchange = (event) => {
    let { name, value } = event.target;
    setData({
      ...data,
      [name]: value,
    });
  };
  const handleSubmit = (event) => {
    event.preventDefault();
    allUsers.forEach((value) => {
      if (data.email === value.email && data.password === value.password) {
        update(true);
      }
    });
    setData({
      email: "",
      password: "",
    });
    history.push("/");
  };

  return (
    <div>
      <div className="container">
        <h3 className="text-center mt-5 mb-3">Login Form</h3>
        <div className="col-lg-6 col-md-6 col-10 mx-auto offset-1">
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <input
                type="email"
                className="form-control"
                placeholder="Enter Email Id"
                name="email"
                value={data.email}
                onChange={handleOnchange}
              />
            </div>
            <div className="form-group">
              <input
                type="password"
                className="form-control"
                placeholder="Enter Password"
                name="password"
                value={data.password}
                onChange={handleOnchange}
              />
            </div>

            <div className="form-group">
              <button type="submit" className="btn btn-primary">
                Login
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Login;
