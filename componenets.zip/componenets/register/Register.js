import React, { Component } from "react";
import "./Register.css";

export default class Register extends Component {
  constructor() {
    super();
    this.state = {
      user: {
        name: "",
        email: "",
        phoneNo: "",
        password: "",
        gender: "",
        address: "",
      },
      allUsers: [],
    };
  }
  handleOnchange = (event) => {
    let { name, value } = event.target;
    this.setState({
      user: {
        ...this.state.user,
        [name]: value,
      },
    });
  };

  submitForm = (e) => {
    e.preventDefault();
    this.setState({ allUsers: [...this.state.allUsers, this.state.user] });
    localStorage.setItem("allUsers", JSON.stringify(this.state.allUsers));
    this.setState({
      user: {
        name: "",
        email: "",
        phoneNo: "",
        password: "",
        gender: "male",
        address: "",
      },
    });
  };
  render() {
    return (
      <div>
        <div className="container">
          <h3 className="text-center mt-5 mb-3">Registration Form</h3>
          <div className="col-lg-6 col-md-6 col-10 mx-auto offset-1">
            <form onSubmit={this.submitForm}>
              <div className="form-group">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Enter Name"
                  name="name"
                  value={this.state.user.name}
                  onChange={this.handleOnchange}
                />
              </div>
              <div className="form-group">
                <input
                  type="email"
                  className="form-control"
                  placeholder="Enter Email Id"
                  name="email"
                  value={this.state.user.email}
                  onChange={this.handleOnchange}
                />
              </div>
              <div className="form-group">
                <input
                  type="tel"
                  className="form-control"
                  placeholder="Enter Phone No"
                  name="phoneNo"
                  value={this.state.user.phoneNo}
                  onChange={this.handleOnchange}
                />
              </div>
              <div className="form-group">
                <input
                  type="password"
                  className="form-control"
                  placeholder="Enter Password"
                  name="password"
                  value={this.state.user.password}
                  onChange={this.handleOnchange}
                />
              </div>
              <div className="form-group">
                Gender:
                <input
                  type="radio"
                  name="gender"
                  value="male"
                  // value={this.state.user.gender}
                  onChange={this.handleOnchange}
                  defaultChecked
                />
                Male
                <input
                  type="radio"
                  name="gender"
                  value="female"
                  onChange={this.handleOnchange}
                />
                Female
              </div>
              <div className="form-group">
                <textarea
                  name="address"
                  id=""
                  cols="30"
                  className="form-control"
                  rows="3"
                  placeholder="Address"
                  value={this.state.user.address}
                  onChange={this.handleOnchange}
                ></textarea>
              </div>
              <div className="form-group">
                <button type="submit" className="btn btn-primary">
                  Register
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    );
  }
}
