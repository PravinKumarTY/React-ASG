import React, { Component } from 'react'

export default class Services extends Component {
    render() {
        return (
            <div>
                <h1>This is Services Component!!!</h1>
            </div>
        )
    }
}
